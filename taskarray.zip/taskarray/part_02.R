#!/usr/bin/env Rscript

# Read in the command argumenent
fname <- commandArgs(trailingOnly = TRUE)
print("Check filename")
fname

library(dplyr)
library(stringr)

# Extract from fname string a pattern of 2 numbers from 0-9
tag <- str_extract(fname, "[0-9]{2}")
print("Check tag")
tag

# Read in the text
original_text <- read.table(paste0("encoded_message/",fname), header = FALSE, sep = "")

# Put together a list of lower-case, upper-case and special characters
char_string <- c(letters, LETTERS, ",", "!")

# Make a sequence of numbers to use for encoding
nchars <- length(char_string)
print("Check number of characters:")
nchars
numeric_vals <- 0:(nchars-1)

if (as.numeric(tag) < 3){
 print("Need to delete if-statement that creates this error")
 stop('find this bug and delete it...')
}

code_df <- data.frame(char_string, numeric_vals)

letters2numbers <- function(letter_set){
  number_set <- list()
  letter_set <- str_split(letter_set, pattern = "") %>% unlist()
  for (i in 1:length(letter_set)){
    idx <- which(code_df$char_string==letter_set[i])
    number_set[[i]] <- code_df$numeric_vals[idx]
  }
  number_set <- do.call(c, number_set)
  return(number_set)
}

numbers2decode <- function(number_set){
  number_set <- (number_set - 10) %% nchars
  code_set <- list()
  for (i in 1:length(number_set)){
    idx <- which(code_df$numeric_vals==number_set[i])
    code_set[[i]] <- code_df$char_string[idx]
  }
  code_set <- do.call(c, code_set)
  return(code_set)
}

decode_msg <- function(code_msg){
  num_code_msg <- letters2numbers(code_msg)
  decoded_msg <- numbers2decode(num_code_msg) %>% paste(collapse="")
  return(decoded_msg)
}

# Apply decoding algorithm to find the hidden message
hidden_msg <- decode_msg(original_text) 

# Create a file save name using the input tag
fsave <- paste0("encoded_message/hidden_msg_", tag, ".csv")

# Write the CSV file
write.table(hidden_msg, fsave, quote = FALSE, row.name = FALSE, col.name = FALSE)



