#!/usr/bin/env Rscript

library(dplyr)

# List all of the files in the folder encoded_message that begin with hidden_msg and end with csv
fnames <- list.files(path = "encoded_message", pattern = glob2rx("hidden_msg*.csv"), full.names = TRUE)
print("Files found:")
fnames

# Read in each word of the message from the different files
msgs <- list()
for (i in 1:length(fnames)){
  msgs[[i]] <- read.csv(fnames[i], header = FALSE)
}

# Use do.call to row bind the data frame pieces together
hidden_msg_df <- do.call(rbind.data.frame, msgs)
colnames(hidden_msg_df) <- "messages"

# Collapse the column into one message
hidden_msg <- paste(hidden_msg_df$messages, collapse = " ")

# Save it
write.table(hidden_msg, "decoded_message.txt", quote = FALSE, row.names = FALSE, col.names = FALSE)

