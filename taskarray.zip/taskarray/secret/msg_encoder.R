#!/usr/bin/env Rscript

library(dplyr)
library(stringr)

msg <- read.table("secret_msg.txt", header = FALSE, sep = "")

encode_function <- function(msg){
  msg_split <- str_split(msg)
}

msg_split <- unlist(str_split(msg, pattern = " "))

char_string <- c(letters, LETTERS, ",", "!")
nchars <- length(char_string)

number_string <- 0:(nchars-1) %>% as.character()

code_df <- data.frame(char_string, number_string)


letters2numbers <- function(letter_set){
  number_set <- list()
  for (i in 1:length(letter_set)){
    idx <- which(code_df$char_string==letter_set[i])
    number_set[[i]] <- code_df$number_string[idx]
  }
  number_set <- do.call(c, number_set)
  return(number_set)
}

numbers2code <- function(number_set){
  number_set <- (as.numeric(number_set) + 10) %% nchars
  code_set <- list()
  for (i in 1:length(number_set)){
    idx <- which(code_df$number_string==number_set[i])
    code_set[[i]] <- code_df$char_string[idx]
  }
  code_set <- do.call(c, code_set)
  return(code_set)
}

msg_chars <- list()
for (i in 1:length(msg_split)){
  msg_orig <- str_extract_all(msg_split[i], boundary("character")) %>% unlist()
  msg_num <- letters2numbers(msg_orig)
  msg_chars[[i]] <- numbers2code(msg_num) %>% paste(collapse="")
  if (i < 10){
    tag <- paste0("0", as.character(i), collapse = "")
  } else{
    tag <- as.character(i)
  }
  write.table(msg_chars[[i]], paste0("../encoded_message/text_", tag, ".txt"), quote = FALSE, row.names = FALSE, col.names = FALSE)
}

