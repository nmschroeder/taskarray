#!/usr/bin/env Rscript

library(dplyr)

fnames <- list.files(path = "encoded_message", pattern = glob2rx("text*.txt"))
print("Files found:")
fnames

fnames_df <- fnames %>% as.data.frame()
print("Data frame structure")
str(fnames_df)

write.table(fnames_df, "part_02_inputs.txt", quote = FALSE, row.names = FALSE, col.names = FALSE)

